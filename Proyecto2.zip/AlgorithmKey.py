from enum import Enum

class AlgorithmKey(Enum):
    MIN = 1
    MAX = 2