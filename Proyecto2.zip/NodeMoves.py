from enum import Enum

class NodeMoves(Enum):
    UP = 1
    DOWN = 2
    LEFT = 3
    RIGHT = 4
